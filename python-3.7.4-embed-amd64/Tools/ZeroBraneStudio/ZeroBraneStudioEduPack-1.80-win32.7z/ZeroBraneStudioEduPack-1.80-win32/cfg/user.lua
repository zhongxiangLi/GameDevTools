--[[--
  Use this file to specify **System** preferences.
  Review [examples](+E:\WorkSpace\Github\GameDevTools\python-3.7.4-embed-amd64\Tools\ZeroBraneStudio\ZeroBraneStudioEduPack-1.80-win32\cfg\user-sample.lua) or check [online documentation](http://studio.zerobrane.com/documentation.html) for details.
--]]--
