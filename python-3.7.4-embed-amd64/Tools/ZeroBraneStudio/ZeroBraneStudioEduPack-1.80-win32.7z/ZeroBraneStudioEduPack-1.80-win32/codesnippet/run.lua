--代码粘贴到这个文件
--F5        开始单步调试
--Shift+F10 单步调试
--F10       Step into
--F6  直接运行
--Project->Lua InterPreter 切换Lua版本

print("welcom")

local function Walk()
    local walk=walk or 0
    print(walk)
end
Walk()

print(math.modf(10070100/10000))
