ZeroBraneStudio 开源免费的lua编辑器
https://github.com/pkulchenko/ZeroBraneStudio

我用来测试lua代码片段

代码粘贴到 run.lua

--F5        开始单步调试
--Shift+F10 单步调试
--F10       Step into
--F6  直接运行

Project->Lua InterPreter 切换Lua版本